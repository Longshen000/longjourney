// Copyright (c) 2019, Zpalmtree
//
// Please see the included LICENSE file for more information.

#include "Blake2/Blake2b.h"

#include <iostream>

void Blake2b::compress()
{
    compressCrossPlatform();
}
